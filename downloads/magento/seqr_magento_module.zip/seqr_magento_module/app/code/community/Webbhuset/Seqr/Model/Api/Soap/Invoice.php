<?php

class Webbhuset_Seqr_Model_Api_Soap_Invoice extends Webbhuset_Seqr_Model_Api_Soap_Abstract
{
    public function __construct()
    {
        $this->setApiType('invoice');
    }

    protected $_issueDate;
    protected $_issueDateSpecified;
    protected $_title;
    protected $_clientInvoiceId;
    protected $_invoiceRows;
    protected $_totalAmount;
    protected $_cashierId;
    protected $_footer;
    protected $_backURL;
}