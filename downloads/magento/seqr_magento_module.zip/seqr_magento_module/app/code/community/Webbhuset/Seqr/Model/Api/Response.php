<?php

class Webbhuset_Seqr_Model_Api_Response extends Varien_Object
{
    protected $_ersReference;
    protected $_resultCode;
    protected $_resultDescription;
}