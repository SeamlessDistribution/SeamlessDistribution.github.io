<?php

class Webbhuset_Seqr_Model_Api_PaymentInvoiceRow extends Varien_Object
{
    protected $_itemDescription;
    protected $_itemDiscount;
    protected $_itemEAN;
    protected $_itemQuantity;
    protected $_itemQuantitySpecified;
    protected $_itemSKU;
    protected $_itemTaxRate;
    protected $_itemTaxRateSpecified;
    protected $_itemTotalAmount;
    protected $_itemUnit;
    protected $_itemUnitPrice;
}