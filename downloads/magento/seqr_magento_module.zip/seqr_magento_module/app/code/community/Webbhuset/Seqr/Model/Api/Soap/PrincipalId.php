<?php

class Webbhuset_Seqr_Model_Api_Soap_PrincipalId extends Webbhuset_Seqr_Model_Api_Soap_Abstract
{
    public function __construct()
    {
        $this->setApiType('principalId');
    }
    
    protected $_id;
    protected $_type;
    protected $_userId;
}