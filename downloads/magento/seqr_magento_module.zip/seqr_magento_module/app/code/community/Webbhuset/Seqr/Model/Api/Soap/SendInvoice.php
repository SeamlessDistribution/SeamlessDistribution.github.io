<?php

class Webbhuset_Seqr_Model_Api_Soap_SendInvoice extends Webbhuset_Seqr_Model_Api_Soap_Abstract
{
    public function __construct()
    {
        $this->setApiType('sendInvoice');
    }
    
    protected $_context;
    protected $_invoice;
}