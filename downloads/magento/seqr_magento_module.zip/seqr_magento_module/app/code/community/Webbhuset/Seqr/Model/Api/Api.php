<?php

class Webbhuset_Seqr_Model_Api_Api
{
    public function sendInvoice(Webbhuset_Seqr_Model_Api_Soap_ClientContext $context, Webbhuset_Seqr_Model_Api_Soap_Invoice $invoice)
    {
        $sendInvoice = Mage::getModel('seqr/api_soap_sendInvoice')
            ->setInvoice($invoice)
            ->setContext($context);

        try {
            $resp = $this
                ->getClient()
                ->sendInvoice($sendInvoice->getSoap());

            if ($resp->return->resultCode != 0) {
                Mage::log('Error: ' . $resp->return->resultCode . ' : ' . $resp->return->resultDescription);
                throw new Exception($resp->return->resultCode . ' : ' . $resp->return->resultDescription);
            }
            else {
                return $resp->return;
            }
        }
        catch (Exception $e) {
            Mage::log('Error: ' . $e->getMessage());
        }

        return null;
    }

    public function getPaymentStatus(Webbhuset_Seqr_Model_Api_Soap_ClientContext $context, $invoiceReference, $invoiceVersion)
    {
        $getPaymentStatus = Mage::getModel('seqr/api_soap_getPaymentStatus')
            ->setInvoiceReference($invoiceReference)
            ->setInvoiceVersion($invoiceVersion)
            ->setContext($context);

        try {
            $resp = $this
                ->getClient()
                ->getPaymentStatus($getPaymentStatus->getSoap());

            if ($resp->return->resultCode !== 0) {
                Mage::log('Error: ' . $resp->return->resultCode . ' : ' . $resp->return->resultDescription);
                throw new Exception($resp->return->resultCode . ' : ' . $resp->return->resultDescription);
            }
            else {
                return $resp->return;
            }
        }
        catch (Exception $e) {
            Mage::log('Error: ' . $e->getMessage());
        }

        return null;
    }

    public function cancelInvoice(Webbhuset_Seqr_Model_Api_Soap_ClientContext $context, $invoiceReference)
    {
        $cancelInvoice = Mage::getModel('seqr/api_soap_cancelInvoice')
            ->setInvoiceReference($invoiceReference)
            ->setContext($context);
        
        try {
            $resp = $this
                ->getClient()
                ->cancelInvoice($cancelInvoice->getSoap());

            if ($resp->return->resultCode !== 0) {
                Mage::log('Error: ' . $resp->return->resultCode . ' : ' . $resp->return->resultDescription);
                throw new Exception($resp->return->resultCode . ' : ' . $resp->return->resultDescription);
            }
            else {
                return $resp->return;
            }
        }
        catch (Exception $e) {
            Mage::log('Error: ' . $e->getMessage());
        }

        return null;
    }

    protected function getClient()
    {
        return new SoapClient(Mage::getStoreConfig('payment/seqr/soap_url'), array('trace' => 1,'connection_timeout' => 300));
    }
}