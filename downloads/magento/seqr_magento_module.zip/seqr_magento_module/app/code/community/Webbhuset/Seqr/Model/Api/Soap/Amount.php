<?php

class Webbhuset_Seqr_Model_Api_Soap_Amount extends Webbhuset_Seqr_Model_Api_Soap_Abstract
{
    public function __construct()
    {
        $this->setApiType('amount');
    }
    
    protected $_currency;
    protected $_value;
    protected $_valueSpecified;
}