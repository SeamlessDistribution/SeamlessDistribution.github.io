<?php

class Webbhuset_Seqr_Model_Api_SendInvoiceResponse extends Webbhuset_Seqr_Model_Api_Response
{
    protected $_invoiceQRCode;
    protected $_invoiceReference;
}