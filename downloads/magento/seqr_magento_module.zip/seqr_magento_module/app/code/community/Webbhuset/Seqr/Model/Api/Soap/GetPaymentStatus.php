<?php

class Webbhuset_Seqr_Model_Api_Soap_GetPaymentStatus extends Webbhuset_Seqr_Model_Api_Soap_Abstract
{
    public function __construct()
    {
        $this->setApiType('getPaymentStatus');
    }
    
    protected $_context;
    protected $_invoiceReference;
    protected $_invoiceVersion;
}