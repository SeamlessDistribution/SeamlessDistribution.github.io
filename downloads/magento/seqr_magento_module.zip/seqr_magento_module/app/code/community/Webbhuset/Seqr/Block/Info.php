<?php

class Webbhuset_Seqr_Block_Info extends Mage_Payment_Block_Info
{
    protected function _toHtml()
    {
        $order = $this
            ->getInfo()
            ->getOrder();

        if ($order) {
            $data = $order
                ->getPayment()
                ->getAdditionalData();

            if ($data) {
                $json = json_decode($data);
                return 'SEQR<br/><strong>Invoice reference</strong>: ' . $json->invoiceReference;
            }
            return 'SEQR - No invoice created';
        }
        return 'SEQR';
    }
}