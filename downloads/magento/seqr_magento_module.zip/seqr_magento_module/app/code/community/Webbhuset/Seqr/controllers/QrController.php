<?php

class Webbhuset_Seqr_QrController extends Mage_Core_Controller_Front_Action
{
    public function confirmAction()
    {
        $orderid = $this->getRequest()->getParam('id');

        if (!$orderid) {
            $orderid = Mage::getSingleton('checkout/session')->getLastOrderId();
        }

        if ($orderid) {
            Mage::register('orderid', $orderid);

            $order = Mage::getModel('sales/order')->load($orderid);

            if ($order->getPayment() !== FALSE) {
                if ($order->getPayment()->getMethodInstance()->getCode() == 'seqr') {
                    //$qrcode = Mage::getSingleton('seqr/invoice')->getQrCode($order);
                    $this->loadLayout();
                    $this->renderLayout();
                    return;
                }
            }
        }
        
        $this->_forward('noRoute');
    }

    public function confirmedAction()
    {
        $orderid = $this->getRequest()->getParam('id');

        if (!$orderid) {
            $orderid = Mage::getSingleton('checkout/session')->getLastOrderId();
        }

        if ($orderid) {
            Mage::register('orderid', $orderid);

            $order = Mage::getModel('sales/order')->load($orderid);

            if ($order->getPayment() !== FALSE) {
                if ($order->getPayment()->getMethodInstance()->getCode() == 'seqr') {
                    $invoice = Mage::getSingleton('seqr/invoice')->getSeqrInvoice($order);
                    $status = Mage::getSingleton('seqr/invoice')->getPaymentStatus($invoice);

                    if (Mage::helper('seqr')->statusIsPaid($status)) {
                        if ($order->getCanSendNewEmailFlag()) {
                            try {
                                $order->sendNewOrderEmail();
                            } catch (Exception $e) {
                                Mage::logException($e);
                            }
                        }
                        $order
                            ->setStatus(Mage::getStoreConfig('payment/seqr/paid_order_status'))
                            ->save();
                        $this->_redirect('checkout/onepage/success', array('_secure'=>true));
                        return;
                    }
                }
            }
        }
        
        $this->_forward('noRoute');
    }

    public function cancelAction()
    {
        $orderid = $this->getRequest()->getParam('id');

        if (!$orderid) {
            $this->_forward('noRoute');
            return;
        }

        if ($orderid) {
            Mage::register('orderid', $orderid);

            $order = Mage::getModel('sales/order')->load($orderid);

            if ($order->getPayment() !== FALSE) {
                if ($order->getPayment()->getMethodInstance()->getCode() == 'seqr') {
                    $invoice = Mage::getSingleton('seqr/invoice')->getSeqrInvoice($order);
                    $status = Mage::getSingleton('seqr/invoice')->getPaymentStatus($invoice);

                    if (!Mage::helper('seqr')->statusIsPaid($status)) {
                        $created = strtotime($order->getCreatedAt());
                        $now = time();
                        $diffSeconds = $now - $created;
                        $secondsBeforeCancel = intval(Mage::getStoreConfig('payment/seqr/seconds_before_cancel'));
                        $invoice = Mage::getSingleton('seqr/invoice')->getSeqrInvoice($order);
                        $canceled = Mage::getSingleton('seqr/invoice')->cancelInvoice($invoice);

                        if ($canceled) {
                            $order
                                ->setStatus(Mage::getStoreConfig('payment/seqr/canceled_order_status'))
                                ->save();
                            $this->_redirect('checkout/onepage/failure', array('_secure'=>true));
                        }
                        return;
                    }
                }
            }
        }
        
        $this->_forward('noRoute');
    }

    public function cancelOldOrdersAction()
    {
        Mage::getModel('seqr/observer')->cancelOldOrders();
    }

    public function pollAction()
    {
        $orderid = $this->getRequest()->getParam('id');

        if (!$orderid) {
            $returnData = array('error' => Mage::helper('seqr')->__('Could not find order'));
        }
        else {
            $order = Mage::getModel('sales/order')->load($orderid);
            if (!$order) {
                $returnData = array('error' => Mage::helper('seqr')->__('Could not find order'));
            }
            else {
                $invoice = Mage::getSingleton('seqr/invoice')->getSeqrInvoice($order);
                $status = Mage::getSingleton('seqr/invoice')->getPaymentStatus($invoice);
                $returnData = array('invoice' => $invoice, 'status' => $status);
            }
        }
        
        $this->getResponse()->setHeader('Content-type', 'application/json', true);
        $this->getResponse()->setBody(Zend_Json::encode($returnData));
    }
}