<?php

class Webbhuset_Seqr_Block_Form extends Mage_Payment_Block_Form
{
    protected $_template = 'seqr/payment/form.phtml';

    protected function getText()
    {
        return Mage::getStoreConfig('payment/seqr/info_in_checkout');
    }
}