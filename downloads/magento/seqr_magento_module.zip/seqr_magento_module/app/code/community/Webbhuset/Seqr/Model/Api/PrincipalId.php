<?php

class Webbhuset_Seqr_Model_Api_PrincipalId extends Varien_Object
{
    protected $_id;
    protected $_type;
    protected $_userId;
}