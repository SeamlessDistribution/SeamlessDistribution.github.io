<?php

class Webbhuset_Seqr_Model_Paymentmethod extends Mage_Payment_Model_Method_Abstract
{
    protected $_code = 'seqr';
    protected $_infoBlockType = 'seqr/info';
    protected $_formBlockType = 'seqr/form';
    
    public function getOrderPlaceRedirectUrl() {
        return Mage::getUrl('seqr/qr/confirm', array('_secure' => true));
    }
}
