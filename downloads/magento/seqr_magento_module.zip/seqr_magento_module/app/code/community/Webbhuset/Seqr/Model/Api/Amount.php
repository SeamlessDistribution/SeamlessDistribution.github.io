<?php

class Webbhuset_Seqr_Model_Api_Amount extends Varien_Object
{
    protected $_currency;
    protected $_value;
    protected $_valueSpecified;
}