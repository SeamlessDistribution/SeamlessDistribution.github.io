<?php

class Webbhuset_Seqr_Model_Api_Soap_Abstract extends Varien_Object
{
    public function __construct()
    {
        $this->setApiType('abstract');
    }

    public function getSoap()
    {
        $data = $this->getData();
        $dataobj = new StdClass();
        foreach ($data as $i => $obj) {
            if ($i == 'api_type') {
                continue;
            }
            $i = Mage::helper('seqr')->toCamelCase($i);
            $dataobj->$i = $obj;
            if ($obj instanceof Webbhuset_Seqr_Model_Api_Soap_Abstract) {
                $dataobj->$i = $obj->getSoap();
            }
            else if (is_array($obj)) {
                $arr = new ArrayObject();
                foreach ($obj as $obj_obj) {
                    if ($obj_obj instanceof Webbhuset_Seqr_Model_Api_Soap_Abstract) {
                        $arr->append($obj_obj->getSoap());
                    }
                }
                $dataobj->$i = $arr;
            }
            else {
                $dataobj->$i = $obj;
            }
        }
        return new SoapVar($dataobj, SOAP_ENC_OBJECT, null, null, $this->getApiType());
    }
}