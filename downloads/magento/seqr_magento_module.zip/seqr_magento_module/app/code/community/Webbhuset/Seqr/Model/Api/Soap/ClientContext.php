<?php

class Webbhuset_Seqr_Model_Api_Soap_ClientContext extends Webbhuset_Seqr_Model_Api_Soap_Abstract
{
    public function __construct()
    {
        $this->setApiType('clientContext');
    }
    
    protected $_channel;
    protected $_clientComment;
    protected $_clientId;
    protected $_clientReference;
    protected $_clientRequestTimeout;
    protected $_initiatorPrincipalId;
    protected $_password;
}