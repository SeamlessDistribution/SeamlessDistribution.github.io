<?php

class Webbhuset_Seqr_Helper_Data extends Mage_Core_Helper_Abstract
{
    public function toCamelCase($string, $capitaliseFirstChar = false) 
    {
        $camelized = str_replace(' ', '', ucwords(str_replace('_', ' ', $string)));
     
        if ($capitaliseFirstChar) {
            return $camelized;
        }
     
        return lcfirst($camelized);
    }

    public function statusIsPaid($status)
    {
        // Possible status: ISSUED, PAID, CANCELED, FAILED
        return $status == 'PAID';
    }
}