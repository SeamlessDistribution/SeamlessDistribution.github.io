<?php

class Webbhuset_Seqr_Model_Api_Soap_Response extends Webbhuset_Seqr_Model_Api_Soap_Abstract
{
    public function __construct()
    {
        $this->setApiType('response');
    }
    
    protected $_ersReference;
    protected $_resultCode;
    protected $_resultDescription;
}