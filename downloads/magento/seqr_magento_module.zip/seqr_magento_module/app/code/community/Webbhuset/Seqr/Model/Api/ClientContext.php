<?php

class Webbhuset_Seqr_Model_Api_ClientContext extends Varien_Object
{
    protected $_channel;
    protected $_clientComment;
    protected $_clientId;
    protected $_clientReference;
    protected $_clientRequestTimeout;
    protected $_initiatorPrincipalId;
    protected $_password;
}