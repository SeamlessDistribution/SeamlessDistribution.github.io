<?php

class Webbhuset_Seqr_Model_Invoice
{
    /**
     * @return The QR code for the invoice
     */
    public function getQrCode(Mage_Sales_Model_Order $order)
    {
        $data = $this->sendInvoice($order);

        if ($data) {
            return $data->invoiceQRCode;
        }
        return NULL;
    }

    /**
     * @return Reference id to invoice
     */
    public function getSeqrInvoice(Mage_Sales_Model_Order $order)
    {
        $data = $this->sendInvoice($order);

        if ($data) {
            return $data->invoiceReference;
        }
        return NULL;
    }

    /**
     * @param $invoiceReference Reference id to invoice
     * @return Payment status
     */
    public function getPaymentStatus($invoiceReference)
    {
        $terminalId = Mage::getStoreConfig('payment/seqr/terminal_id');
        $terminalPassword = Mage::getStoreConfig('payment/seqr/terminal_password');
        
        $context = $this->createContextForTerminalId($terminalPassword, $terminalId);
        $invoiceVersion = 0;
        $data = Mage::getSingleton('seqr/api_api')->getPaymentStatus($context, $invoiceReference, $invoiceVersion);
        return $data->status;
    }

    /**
     * @param $invoiceReference Reference id to invoice
     * @return If invoice was canceled successfully
     */
    public function cancelInvoice($invoiceReference)
    {
        $terminalId = Mage::getStoreConfig('payment/seqr/terminal_id');
        $terminalPassword = Mage::getStoreConfig('payment/seqr/terminal_password');
        
        $context = $this->createContextForTerminalId($terminalPassword, $terminalId);
        $data = Mage::getSingleton('seqr/api_api')->cancelInvoice($context, $invoiceReference);
        return ($data && $data->resultCode === 0);
    }

    protected function sendInvoice(Mage_Sales_Model_Order $order)
    {
        $data = $order
            ->getPayment()
            ->getAdditionalData();

        if ($data) {
            return json_decode($data);
        }
        else {
            $terminalId = Mage::getStoreConfig('payment/seqr/terminal_id');
            $terminalPassword = Mage::getStoreConfig('payment/seqr/terminal_password');
            
            $context = $this->createContextForTerminalId($terminalPassword, $terminalId);
            $invoice = $this->createInvoice($order);
            $data = Mage::getSingleton('seqr/api_api')->sendInvoice($context, $invoice);

            if ($data) {
                $order->getPayment()
                    ->setAdditionalData(json_encode($data))
                    ->save();

                return $data;
            }
            return NULL;
        }

        return NULL;
    }

    // This is context is used for administrative tasks.
    protected function createContextForTerminalId($terminalPassword, $terminalId)
    {
        // Create a principal as RESELLERUSER. Do not use TERMINALID or else when you register a terminal.
        $principalId = Mage::getModel('seqr/api_soap_principalId') // seqrWebRef.principalId
            ->setId($terminalId)        // Id of the registered terminal
            ->setType('TERMINALID')    // Use registered Terminalid
            ->setUserId('');            // N/A

        $version = Mage::getConfig()->getNode()->modules->Webbhuset_Seqr->version;
        if (!$version) {
            $version = '0.9';
        }

        $context = Mage::getModel('seqr/api_soap_clientContext') // seqrWebRef.clientContext
            ->setClientId('Webbhuset SEQR ' . $version)    // Your POS name or similar
            ->setChannel('WS')                     // Always use WS, ignore all other suggestions from documentation
            ->setClientRequestTimeout(0)           // Turn off client timeout
            ->setInitiatorPrincipalId($principalId)
            ->setPassword($terminalPassword)      // When principal is RESELLERUSER use "Lösenord" from "Uppgifter"
            ->setClientComment('Webbhuset SEQR ' . $version);

        return $context;
    }

    protected function createInvoice(Mage_Sales_Model_Order $order)
    {
        $helper = Mage::helper('seqr');
        $currencyCode = $order->getOrderCurrencyCode();
        $items = $order->getAllVisibleItems();
        $invoiceRows = array();

        $totalPrice = Mage::getModel('seqr/api_soap_amount')
            ->setCurrency($currencyCode)
            ->setValue($order->getGrandTotal());

        foreach ($items as $itemId => $item) {
            $invoiceRows[] = Mage::getModel('seqr/api_soap_invoiceRow')
                ->setItemDescription($item->getName())
                ->setItemQuantity($item->getQtyOrdered())
                ->setData('itemSKU', $item->getSku())
                ->setItemTaxRate($item->getTaxPercent())
                ->setItemTotalAmount(Mage::getModel('seqr/api_soap_amount')
                                        ->setCurrency($currencyCode)
                                        ->setValue($item->getRowTotalInclTax()))
                ->setItemUnit(Mage::getStoreConfig('payment/seqr/unit_type'))
                ->setItemUnitPrice(Mage::getModel('seqr/api_soap_amount')
                                        ->setCurrency($currencyCode)
                                        ->setValue($item->getPriceInclTax()));
        }

        // Shipping & Handling
        if ($order->getShippingInclTax() && intval($order->getShippingInclTax())) {
            $invoiceRows[] = Mage::getModel('seqr/api_soap_invoiceRow')
                ->setItemDescription($helper->__('Shipping & Handling'))
                ->setItemQuantity(1)
                ->setItemTaxRate( ($order->getShippingTaxAmount() - 1) * 100 )
                ->setItemTotalAmount(Mage::getModel('seqr/api_soap_amount')
                                        ->setCurrency($currencyCode)
                                        ->setValue($order->getShippingInclTax()))
                ->setItemUnit('')
                ->setItemUnitPrice(Mage::getModel('seqr/api_soap_amount')
                                        ->setCurrency($currencyCode)
                                        ->setValue($order->getShippingInclTax()));
        }

        // Discount
        if ($order->getDiscountAmount() && intval($order->getDiscountAmount())) {
            $invoiceRows[] = Mage::getModel('seqr/api_soap_invoiceRow')
                ->setItemDescription($helper->__('Discount'))
                ->setItemQuantity(1)
                ->setItemTaxRate( ($order->getShippingTaxAmount() - 1) * 100 )
                ->setItemTotalAmount(Mage::getModel('seqr/api_soap_amount')
                                        ->setCurrency($currencyCode)
                                        ->setValue($order->getDiscountAmount()))
                ->setItemUnit('')
                ->setItemUnitPrice(Mage::getModel('seqr/api_soap_amount')
                                        ->setCurrency($currencyCode)
                                        ->setValue($order->getDiscountAmount()));
        }

        // Shipping discount
        if ($order->getShippingDiscountAmount() && intval($order->getShippingDiscountAmount())) {
            $invoiceRows[] = Mage::getModel('seqr/api_soap_invoiceRow')
                ->setItemDescription($helper->__('Shipping Discount'))
                ->setItemQuantity(1)
                ->setItemTaxRate( ($order->getShippingTaxAmount() - 1) * 100 )
                ->setItemTotalAmount(Mage::getModel('seqr/api_soap_amount')
                                        ->setCurrency($currencyCode)
                                        ->setValue($order->getShippingDiscountAmount()))
                ->setItemUnit('')
                ->setItemUnitPrice(Mage::getModel('seqr/api_soap_amount')
                                        ->setCurrency($currencyCode)
                                        ->setValue($order->getShippingDiscountAmount()));
        }

        $invoice = Mage::getModel('seqr/api_soap_invoice')
            //->setCashierId('Bob Smith')
            ->setTotalAmount($totalPrice)
            ->setIssueDate(date('Y-m-d'))
            ->setTitle(Mage::getStoreConfig('payment/seqr/title'))
        // invoice.backURL - Use this for mobile web-stores to enter the URL where to be redirected after the payment is complete 
            ->setData('backURL', Mage::getUrl('seqr/qr/confirmed/id/'.$order->getId().'/'))
            ->setFooter(Mage::getStoreConfig('payment/seqr/footer'))

        // With clientInvoiceId you make a reference between the SEQR invoice and
        // what you probably call recepitId in your system.
        // E.g. A customer complains about a payment, we go back to the shop owner and ask them tell us what was 
        // the contents of the transaction with clientInvoiceID X. They should be able to give us the details.
            ->setClientInvoiceId($order->getIncrementId())

        // Add article rows and discounts
            ->setInvoiceRows($invoiceRows);
        return $invoice;

        /*$totalPrice = Mage::getModel('seqr/api_soap_amount')
            ->setCurrency('SEK')
            ->setValue(($amountOfCocaCola * $priceEach) - 10); // Observe this discount of 10 drawn from total!! It´s treated as discount when a paymentInvoiceRow is added below.

        $invoice = Mage::getModel('seqr/api_soap_invoice')
            ->setCashierId('Bob Smith')
            ->setTotalAmount($totalPrice)
            ->setIssueDate(date('Y-m-d'))
            ->setTitle('SEQR .Net test Client')
        // invoice.backURL - Use this for mobile web-stores to enter the URL where to be redirected after the payment is complete 
            ->setFooter('Purchase on approval is valid for 30 days')

        // With clientInvoiceId you make a reference between the SEQR invoice and
        // what you probably call recepitId in your system.
        // E.g. A customer complains about a payment, we go back to the shop owner and ask them tell us what was 
        // the contents of the transaction with clientInvoiceID X. They should be able to give us the details.
            ->setClientInvoiceId("35423532")

        // Add article rows and discounts
            ->setInvoiceRows(array(
                Mage::getModel('seqr/api_soap_invoiceRow')
                    ->setItemDescription('Coca cola')
                    //->setItemEAN('73829482372812')
                    ->setItemQuantity($amountOfCocaCola)
                    ->setData('itemSKU', 'coca-cola')
                    ->setItemTaxRate(25)
                    ->setItemTotalAmount(Mage::getModel('seqr/api_soap_amount')
                                            ->setCurrency('SEK')
                                            ->setValue($amountOfCocaCola * $priceEach))
                    ->setItemUnit('Piece')
                    ->setItemUnitPrice(Mage::getModel('seqr/api_soap_amount')
                                            ->setCurrency('SEK')
                                            ->setValue($priceEach)),

                Mage::getModel('seqr/api_soap_invoiceRow')
                    ->setItemDescription('Receipt discount')
                    //->setItemEAN('')
                    ->setItemQuantity(1)
                    //->setItemSKU('')
                    ->setItemTaxRate(25)
                    ->setItemTotalAmount(Mage::getModel('seqr/api_soap_amount')
                                            ->setCurrency('SEK')
                                            ->setValue(-10))
                    ->setItemUnit('')
                    ->setItemUnitPrice(Mage::getModel('seqr/api_soap_amount')
                                            ->setCurrency('SEK')
                                            ->setValue(-10)),
            ));
        return $invoice;*/
    }
}