<?php

class Webbhuset_Seqr_Model_Api_Soap_CancelInvoice extends Webbhuset_Seqr_Model_Api_Soap_Abstract
{
    public function __construct()
    {
        $this->setApiType('cancelInvoice');
    }
    
    protected $_context;
    protected $_invoiceReference;
}