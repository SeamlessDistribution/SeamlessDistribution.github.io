<?php

class Webbhuset_Seqr_Model_Api_SendInvoice extends Varien_Object
{
    protected $_context;
    protected $_invoice;
}