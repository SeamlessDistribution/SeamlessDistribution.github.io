<?php

class Webbhuset_Seqr_Block_Qr extends Mage_Core_Block_Template
{
    protected $_template = 'seqr/qr.phtml';

    protected function getOrderId()
    {
        return Mage::registry('orderid');
    }

    protected function getSecondsBeforeCancel()
    {
        return intval(Mage::getStoreConfig('payment/seqr/seconds_before_cancel'));
    }

    protected function getQrCode()
    {
        $order = Mage::getModel('sales/order')->load(Mage::registry('orderid'));
        
        $qrcode = Mage::getSingleton('seqr/invoice')->getQrCode($order);
        $invoice = Mage::getSingleton('seqr/invoice')->getSeqrInvoice($order);

        return $qrcode;
    }

    protected function getSeqrUrl()
    {
        $qrcode = $this->getQrCode();

        if (Mage::getStoreConfig('payment/seqr/debug')) {
            return preg_replace('/^HTTP\:\/\//', 'SEQR-DEBUG://', $qrcode);
        }
        else {
            return preg_replace('/^HTTP\:\/\//', 'SEQR://', $qrcode);
        }
    }

    protected function getInformation()
    {
        return Mage::getStoreConfig('payment/seqr/info_in_paygate');
    }

    protected function getLoaderImage()
    {
        return $this->getSkinUrl('images/seqr/loader.gif');
    }
}