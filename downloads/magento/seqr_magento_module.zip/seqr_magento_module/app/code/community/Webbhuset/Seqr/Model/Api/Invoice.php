<?php

class Webbhuset_Seqr_Model_Api_Invoice extends Varien_Object
{
    protected $_issueDate;
    protected $_issueDateSpecified;
    protected $_title;
    protected $_clientInvoiceId;
    protected $_invoiceRows;
    protected $_totalAmount;
    protected $_cashierId;
    protected $_footer;
    protected $_backURL;
}