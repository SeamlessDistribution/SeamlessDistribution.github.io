// Start polling
(function() {
    var INTERVAL = 3000,
        STATUS = {
            ISSUED: 'ISSUED',
            PAID: 'PAID',
            CANCELED: 'CANCELED',
            FAILED: 'FAILED'
        },
        Seqr = { orderid: 0, intervaltime: 0, secondsBeforeCancel: 120 };

    function poll() {
        Seqr.intervaltime += INTERVAL / 1000;
        if (Seqr.intervaltime >= Seqr.secondsBeforeCancel) {
            window.location.href = '/seqr/qr/cancel/id/' + Seqr.orderid;
        }
        else {
            new Ajax.Request('/seqr/qr/poll/',
            {
                method:'post',
                parameters: {id:Seqr.orderid},
                onSuccess: function(data){
                    if (data.responseJSON.status == STATUS.PAID) {
                        window.location.href = '/seqr/qr/confirmed/id/' + Seqr.orderid;
                    }
                    else {
                        //console.log('Status: ' + data.responseJSON.status);
                        setTimeout(poll, INTERVAL);
                    }
                }
            });
        }
    }

    Event.observe(window, 'load', function() {
        Seqr.orderid = $('seqr-orderid').value;
        Seqr.secondsBeforeCancel = $('seqr-seconds-before-cancel').value;
        poll();
    });
}());