var SeqrCheckout = (function() {
    var _private = {
        div: null
    };
    return {
        show: function(from_element) {
            if (_private.div != null) {
                _private.div.show();
            }
            else {
                _private.div = document.createElement('div').addClassName('seqr-info-text');
                _private.div.innerHTML = from_element.innerHTML;
                $(document.body).insert(_private.div);
            }
        }
    }
}());